var server = require('./libs/coap-broker');
server.start();
